# Readme

For the detailed report on the project, read report.md. 

For testing, see solve_sudoku.py. 

The majority of the testing is discussed in the report: see there. The comments in the solve_sudoku file show how to run the tests easily and explain the structure of the code. 